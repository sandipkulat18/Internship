#!/usr/bin/env python
# coding: utf-8

# In[2]:


Q1=('Answer is B')
print(Q1)


# In[3]:


Q2= ('Answer Is  C')
print(Q2)


# In[4]:


Q3=('Answer iS A')
print(Q3)


# In[5]:


Q4=('Answer Is B')
print(Q4)


# In[7]:


Q5=('Answer is B')
print(Q5)


# In[8]:


Q6=('Answer is B')
print(Q6)


# In[9]:


Q7=('Answer is A')
print(Q7)


# In[13]:


Q8=('Answer Is B')
print(Q8,"= Scatterplot")


# In[14]:


Q9=('Answer Is D')
print(Q9,"= Analysis of Variance")


# In[15]:


Q10=('Answer Is b')
print(Q10,"= t score")


# In[16]:


Q11=('Answer Is C')
print(Q11,"= mean")


# In[17]:


Q12=('Answer Is D')
print(Q12,"= 400005.2")


# In[20]:


Q13=('Answer Is D')
print(Q13,"= mean")


# In[21]:


Q14=('Answer Is A')
print(Q14,'=Descriptive and inferential')


# In[22]:


Q15=('Answer Is D')
print(Q15,"= H-L")


# In[ ]:




