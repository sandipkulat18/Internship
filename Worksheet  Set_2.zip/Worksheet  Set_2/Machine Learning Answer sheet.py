#!/usr/bin/env python
# coding: utf-8

# # MACHINE LEARNING Answer sheet

# In[15]:


Q1=('Answer is option  A')
print(Q1)


# In[16]:


Q2=('Answer is option D')
print(Q2)


# In[17]:


Q3 = ('answer is a A')
print(Q3)


# In[18]:


Q4= ('answer is a A')
print(Q4)


# In[19]:


Q5 =('answer is B')
print(Q5)


# In[20]:


Q6=('Answer is B')
print(Q6)


# In[21]:


Q7= ('Answer is A')
print(Q7)


# In[22]:


Q8= ('Answer is D')
print(Q8)


# In[23]:


Q9=('Anwer is A')
print(Q9)


# In[24]:


Q10=("Answer is D")
print(Q10)


# In[25]:


Q11=("Answer is D")
print(Q11)


# In[26]:


Q12=('K-mean clustering algorithum is sensitive Outlier. easily influenced by extreme values. ')
print(Q12)


# In[29]:


Q13=('k-means is one of the simplest algorithm which uses unsupervised machine learing  method to solve known clustering issues. it is works really well on large datasets.')
print(Q13)


# In[30]:


Q14=('deterministic algorithm is a non-deterministic nature of K-Means is due to random selection of data point as initial centroids')
print(Q14)


# In[ ]:




