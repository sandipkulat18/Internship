#!/usr/bin/env python
# coding: utf-8

# In[1]:


Q1=('Answer is D')
print(Q1)


# In[2]:


Q2=('Answer is C')
print(Q2)


# In[3]:


Q3=('Answer is A')
print(Q3)


# In[5]:


Q4=('Answer is D')
print(Q4)


# In[7]:


Q5=('Answer is B')
print(Q5)


# In[9]:


Q6=('Answer is D')
print(Q6)


# In[10]:


Q7=('Answer is A')
print(Q7)


# In[11]:


Q8=('Answer is C')
print(Q8)


# In[12]:


Q9=('Answer is A')
print(Q9)


# In[13]:


Q10=('Answer is D')
print(Q10)


# In[14]:


Q11=('Answer is B')
print(Q11)


# In[15]:


Q12=('Answer is D')
print(Q12)


# In[16]:


Q13=('Answer is A')
print(Q13)


# In[17]:


Q14=('Answer is B,C,D')
print(Q14)


# In[18]:


Q15=('Answer is A & B')
print(Q15)


# In[ ]:




